$(document).ready(function () {
    var ray = [];
    var port = chrome.runtime.connect({ name: "wine" });
    port.postMessage({ getRay: "need" });
    port.onMessage.addListener(function (msg) {
        console.log("test");
        if (msg.getRay == "receive") {
            ray = msg.sendRay;
            console.log(ray);
            var elements = document.getElementsByTagName('*');
            for (var k = 0; k < ray.length - 1; k += 2){
                for (var i = 0; i < elements.length; i++) {
                    var element = elements[i];

                    for (var j = 0; j < element.childNodes.length; j++) {
                        var node = element.childNodes[j];

                        if (node.nodeType === 3) {
                            var text = node.nodeValue;


                            var replacedText = text.replace('' + ray[k] + '', '' + ray[k+1] + '');
                            //console.log(replacedText);

                
                            if (replacedText !== text) {
                                element.replaceChild(document.createTextNode(replacedText), node);
                            }
                        }
                    }
                }console.log("k");
            }
        }
    });
    
});